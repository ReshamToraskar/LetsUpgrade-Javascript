// Program to convert minutes to seconds
console.log('Question 2')
var min = Number(12)
console.log('Given minutes are:')
var sec = min * 60
console.log('12 minutes into seconds = ', sec)