// Program to search for a element in a array of strings
console.log('Question 3')
var series = ["Dark", "Prison Break", "Lucifer", "Supernatural", "The Mentallist"];
console.log("The given array is:", series)
var a = series.indexOf("The Mentallist");
console.log("The Mentallist is at the index:", a)