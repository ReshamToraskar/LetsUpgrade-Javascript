// Program to search for a particular character in string
console.log('Question 1')
var name = "Resham";
console.log("Given string is:", name)
var n = name.indexOf("e");
console.log("The first occurence of e is at",n)